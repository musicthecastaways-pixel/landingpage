"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import MobileMenu from "@/components/MobileMenu";

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/shows", label: "Shows" },
  { href: "/photos", label: "Photos" },
  { href: "/releases", label: "Releases" },
  { href: "/about", label: "About" },
  { href: "/merch", label: "Merch" },
  { href: "/contact", label: "Contact" },
];

export default function SiteHeader() {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    // Close the mobile menu on route change.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMenuOpen(false);
  }, [pathname]);

  return (
    <header
      className={`sticky top-0 z-50 border-b transition-colors duration-300 ${
        scrolled
          ? "bg-ink/90 backdrop-blur border-line"
          : "bg-transparent border-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-[1400px] items-center justify-between px-5 py-4 sm:px-8">
        <Link
          href="/"
          className="flex items-center gap-2.5 font-display text-lg font-semibold tracking-tight focus-ring"
        >
          <Image
            src="/images/band/logo-halftone.png"
            alt="The Castaways"
            width={32}
            height={32}
            className="h-8 w-8 object-contain"
          />
          The Castaways
        </Link>

        <nav className="hidden items-center gap-7 lg:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`underline-hover focus-ring font-mono text-[13px] uppercase tracking-wide ${
                pathname === link.href ? "text-paper" : "text-paper-dim"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:block">
          <Link
            href="/contact"
            className="focus-ring border border-accent px-4 py-2 font-mono text-[13px] uppercase tracking-wide text-accent-bright transition-colors hover:bg-accent hover:text-paper"
          >
            Book Us
          </Link>
        </div>

        <button
          type="button"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((v) => !v)}
          className="focus-ring flex h-9 w-9 flex-col items-end justify-center gap-1.5 lg:hidden"
        >
          <span
            className={`h-px bg-paper transition-all duration-300 ${
              menuOpen ? "w-6 translate-y-[3.5px] rotate-45" : "w-6"
            }`}
          />
          <span
            className={`h-px bg-paper transition-all duration-300 ${
              menuOpen ? "w-6 -translate-y-[3.5px] -rotate-45" : "w-4"
            }`}
          />
        </button>
      </div>

      <MobileMenu open={menuOpen} links={navLinks} />
    </header>
  );
}
