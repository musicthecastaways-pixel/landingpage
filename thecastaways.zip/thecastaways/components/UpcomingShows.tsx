import Link from "next/link";
import { getUpcomingShows } from "@/lib/shows";
import ShowItem from "@/components/ShowItem";
import SectionHeading from "@/components/ui/SectionHeading";
import Reveal from "@/components/Reveal";

export default function UpcomingShows() {
  const upcoming = getUpcomingShows().slice(0, 4);

  if (upcoming.length === 0) return null;

  return (
    <section className="border-t border-line px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-[1400px]">
        <SectionHeading
          eyebrow="Live"
          title="Upcoming"
          action={
            <Link
              href="/shows"
              className="underline-hover focus-ring font-mono text-xs uppercase tracking-wide text-paper-dim"
            >
              View All Shows
            </Link>
          }
        />
        <div className="grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
          {upcoming.map((show, i) => (
            <Reveal key={`${show.date}-${show.venue}`} delay={i * 80}>
              <ShowItem show={show} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
