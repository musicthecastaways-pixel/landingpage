"use client";

import Link from "next/link";

type NavLink = { href: string; label: string };

export default function MobileMenu({
  open,
  links,
}: {
  open: boolean;
  links: NavLink[];
}) {
  return (
    <div
      id="mobile-menu"
      className={`fixed inset-x-0 top-[61px] bottom-0 z-40 flex flex-col bg-ink px-6 pt-6 transition-transform duration-300 ease-out lg:hidden ${
        open ? "translate-x-0" : "translate-x-full"
      }`}
      aria-hidden={!open}
    >
      <nav className="flex flex-col gap-1">
        {links.map((link, i) => (
          <Link
            key={link.href}
            href={link.href}
            tabIndex={open ? 0 : -1}
            className="focus-ring border-b border-line py-4 font-display text-3xl font-medium"
            style={{ transitionDelay: `${i * 30}ms` }}
          >
            {link.label}
          </Link>
        ))}
      </nav>
      <Link
        href="/contact"
        tabIndex={open ? 0 : -1}
        className="focus-ring mt-8 inline-block w-fit border border-accent px-5 py-3 font-mono text-sm uppercase tracking-wide text-accent-bright"
      >
        Book Us
      </Link>
      <p className="mt-auto mb-8 font-mono text-xs uppercase tracking-wide text-paper-faint">
        Pelotas, Brazil — Est. 2021
      </p>
    </div>
  );
}
