import { band } from "@/content/band";

export default function BookingCTA() {
  return (
    <section className="border-t border-line px-5 py-24 sm:px-8 sm:py-32">
      <div className="mx-auto max-w-[1400px] text-center">
        <h2 className="mx-auto max-w-4xl font-display text-4xl font-semibold leading-[1.02] tracking-tight sm:text-6xl">
          Bring The Castaways to your stage.
        </h2>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-5">
          <a
            href={`mailto:${band.email}`}
            className="focus-ring border border-paper px-7 py-4 font-mono text-sm uppercase tracking-wide transition-colors hover:bg-paper hover:text-ink"
          >
            Book Us
          </a>
          <a
            href={band.epk.href}
            className="focus-ring border border-accent px-7 py-4 font-mono text-sm uppercase tracking-wide text-accent-bright transition-colors hover:bg-accent hover:text-paper"
          >
            Download EPK
          </a>
        </div>
        <p className="mt-6 font-mono text-xs uppercase tracking-wide text-paper-faint">
          {band.email}
        </p>
      </div>
    </section>
  );
}
