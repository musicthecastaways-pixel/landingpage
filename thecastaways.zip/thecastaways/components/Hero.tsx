"use client";

import { useRef, useState } from "react";
import { band } from "@/content/band";

export default function Hero() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [soundOn, setSoundOn] = useState(false);

  function toggleSound() {
    const video = videoRef.current;
    if (!video) return;
    const next = !soundOn;
    video.muted = !next;
    if (next) video.play().catch(() => {});
    setSoundOn(next);
  }

  return (
    <section className="relative flex h-[92vh] min-h-[560px] w-full items-end overflow-hidden bg-ink">
      <video
        ref={videoRef}
        className="absolute inset-0 h-full w-full object-cover opacity-70"
        autoPlay
        muted
        loop
        playsInline
        preload="none"
        poster="/images/band/hero-poster.svg"
      >
        {/* Replace with the real performance reel: /videos/hero.mp4 */}
      </video>

      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(180deg, rgba(10,10,9,0.35) 0%, rgba(10,10,9,0.2) 40%, rgba(10,10,9,0.95) 100%)",
        }}
      />

      <div className="relative z-10 w-full px-5 pb-14 sm:px-8 sm:pb-20">
        <div className="mx-auto max-w-[1400px]">
          <p className="mb-3 animate-hero-in font-mono text-xs uppercase tracking-[0.25em] text-paper-dim [animation-delay:0ms]">
            {band.city.toUpperCase()}, {band.country.toUpperCase()} — EST.{" "}
            {band.formedYear}
          </p>

          <h1 className="animate-hero-in font-display text-[15vw] font-semibold leading-[0.9] tracking-tight [animation-delay:90ms] sm:text-[9vw] lg:text-[7.5vw]">
            THE CASTAWAYS
          </h1>

          <div className="mt-6 flex animate-hero-in items-center gap-6 [animation-delay:180ms]">
            <button
              type="button"
              onClick={toggleSound}
              className="focus-ring flex items-center gap-2 border border-paper/30 px-4 py-2 font-mono text-xs uppercase tracking-wide text-paper-dim transition-colors hover:border-paper hover:text-paper"
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  soundOn ? "bg-accent-bright" : "bg-paper-faint"
                }`}
              />
              {soundOn ? "Sound On" : "Sound Off"}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
