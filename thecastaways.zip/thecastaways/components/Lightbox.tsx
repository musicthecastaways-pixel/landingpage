"use client";

import Image from "next/image";
import { useEffect } from "react";
import { Photo } from "@/content/types";

export default function Lightbox({
  photos,
  activeIndex,
  onClose,
  onNavigate,
}: {
  photos: Photo[];
  activeIndex: number | null;
  onClose: () => void;
  onNavigate: (index: number) => void;
}) {
  const open = activeIndex !== null;
  const photo = open ? photos[activeIndex!] : null;

  useEffect(() => {
    if (!open) return;

    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight")
        onNavigate(((activeIndex as number) + 1) % photos.length);
      if (e.key === "ArrowLeft")
        onNavigate(
          ((activeIndex as number) - 1 + photos.length) % photos.length
        );
    }
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, activeIndex, photos.length, onClose, onNavigate]);

  if (!open || !photo) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${photo.event} photo viewer`}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-ink/96 px-4 py-10"
      onClick={onClose}
    >
      <button
        type="button"
        onClick={onClose}
        aria-label="Close"
        className="focus-ring absolute right-5 top-5 font-mono text-sm uppercase tracking-wide text-paper-dim hover:text-paper"
      >
        Close ✕
      </button>

      <button
        type="button"
        aria-label="Previous photo"
        onClick={(e) => {
          e.stopPropagation();
          onNavigate((activeIndex! - 1 + photos.length) % photos.length);
        }}
        className="focus-ring absolute left-3 top-1/2 -translate-y-1/2 px-3 py-6 font-display text-3xl text-paper-dim hover:text-paper sm:left-6"
      >
        ‹
      </button>

      <div
        className="relative max-h-[80vh] w-full max-w-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative aspect-[4/5] w-full">
          <Image
            src={photo.src}
            alt={photo.alt}
            fill
            sizes="90vw"
            className="object-contain"
          />
        </div>
        <div className="mt-4 text-center">
          <p className="font-mono text-xs uppercase tracking-wide text-paper">
            {photo.event}
            {photo.city ? ` — ${photo.city}` : ""}
          </p>
          {photo.photographer && (
            <p className="mt-1 font-mono text-[11px] uppercase tracking-wide text-paper-faint">
              Photo by {photo.photographer}
            </p>
          )}
        </div>
      </div>

      <button
        type="button"
        aria-label="Next photo"
        onClick={(e) => {
          e.stopPropagation();
          onNavigate((activeIndex! + 1) % photos.length);
        }}
        className="focus-ring absolute right-3 top-1/2 -translate-y-1/2 px-3 py-6 font-display text-3xl text-paper-dim hover:text-paper sm:right-6"
      >
        ›
      </button>
    </div>
  );
}
