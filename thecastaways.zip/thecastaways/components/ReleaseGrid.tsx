import { Release } from "@/content/types";
import ReleaseCard from "@/components/ReleaseCard";
import Reveal from "@/components/Reveal";

export default function ReleaseGrid({ releases }: { releases: Release[] }) {
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-4">
      {releases.map((r, i) => (
        <Reveal key={r.slug} delay={i * 70}>
          <ReleaseCard release={r} />
        </Reveal>
      ))}
    </div>
  );
}
