import Image from "next/image";
import Link from "next/link";
import { photos } from "@/content/photos";
import Reveal from "@/components/Reveal";

export default function SelectedPhotos() {
  const [a, b, c] = photos;

  return (
    <section className="border-t border-line px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-[1400px]">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
            Live &amp; In Frame
          </p>
          <Link
            href="/photos"
            className="underline-hover focus-ring font-mono text-xs uppercase tracking-wide text-paper-dim"
          >
            View Photo Archive
          </Link>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-6 sm:gap-6">
          <Reveal className="relative col-span-2 row-span-2 aspect-[3/4] overflow-hidden bg-ink-raised sm:col-span-3">
            <Image
              src={a.src}
              alt={a.alt}
              fill
              sizes="(min-width: 640px) 45vw, 90vw"
              className="object-cover"
            />
          </Reveal>
          <Reveal
            delay={120}
            className="relative col-span-1 aspect-square overflow-hidden bg-ink-raised sm:col-span-2 sm:mt-14"
          >
            <Image
              src={b.src}
              alt={b.alt}
              fill
              sizes="(min-width: 640px) 30vw, 45vw"
              className="object-cover"
            />
          </Reveal>
          <Reveal
            delay={220}
            className="relative col-span-1 aspect-[3/4] overflow-hidden bg-ink-raised sm:col-span-1"
          >
            <Image
              src={c.src}
              alt={c.alt}
              fill
              sizes="(min-width: 640px) 15vw, 45vw"
              className="object-cover"
            />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
