import Link from "next/link";
import { band } from "@/content/band";
import { socials } from "@/content/socials";

export default function SiteFooter() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto max-w-[1400px] px-5 py-14 sm:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <p className="font-display text-xl font-semibold">
              {band.name}
            </p>
            <p className="mt-2 font-mono text-xs uppercase tracking-wide text-paper-faint">
              {band.city}, {band.country}
            </p>
          </div>

          <nav className="flex flex-col gap-2">
            <FooterHeading>Navigate</FooterHeading>
            <FooterLink href="/shows">Shows</FooterLink>
            <FooterLink href="/photos">Photos</FooterLink>
            <FooterLink href="/releases">Releases</FooterLink>
            <FooterLink href="/about">About</FooterLink>
          </nav>

          <nav className="flex flex-col gap-2">
            <FooterHeading>Connect</FooterHeading>
            <FooterLink href={socials.instagram}>Instagram</FooterLink>
            <FooterLink href={socials.spotify || "/contact"}>
              Spotify
            </FooterLink>
            <FooterLink href={socials.youtube || "/contact"}>
              YouTube
            </FooterLink>
          </nav>

          <nav className="flex flex-col gap-2">
            <FooterHeading>Booking</FooterHeading>
            <FooterLink href="/contact">Contact</FooterLink>
            <FooterLink href="/contact">Book Us</FooterLink>
            <FooterLink href={band.epk.href}>Download EPK</FooterLink>
            <a
              href={`mailto:${band.email}`}
              className="underline-hover focus-ring w-fit font-mono text-sm text-paper-dim"
            >
              {band.email}
            </a>
          </nav>
        </div>

        <div className="mt-14 flex flex-col gap-2 border-t border-line pt-6 font-mono text-xs uppercase tracking-wide text-paper-faint sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {new Date().getFullYear()} {band.name}. All rights reserved.
          </p>
          <p>{band.origin}</p>
        </div>
      </div>
    </footer>
  );
}

function FooterHeading({ children }: { children: React.ReactNode }) {
  return (
    <p className="mb-1 font-mono text-xs uppercase tracking-wide text-paper-faint">
      {children}
    </p>
  );
}

function FooterLink({
  href,
  children,
}: {
  href: string;
  children: React.ReactNode;
}) {
  const external = href.startsWith("http");
  return (
    <Link
      href={href}
      target={external ? "_blank" : undefined}
      rel={external ? "noopener noreferrer" : undefined}
      className="underline-hover focus-ring w-fit text-sm text-paper-dim"
    >
      {children}
    </Link>
  );
}
