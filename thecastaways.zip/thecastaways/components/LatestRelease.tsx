import Image from "next/image";
import Link from "next/link";
import { currentRelease } from "@/content/releases";
import ArrowLink from "@/components/ui/ArrowLink";
import Reveal from "@/components/Reveal";

export default function LatestRelease() {
  const r = currentRelease;
  return (
    <section className="border-t border-line px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto grid max-w-[1400px] gap-10 lg:grid-cols-[minmax(0,480px)_1fr] lg:gap-16">
        <Reveal className="relative aspect-square w-full max-w-[480px] overflow-hidden bg-ink-raised">
          <Image
            src={r.cover}
            alt={`${r.title} cover art`}
            fill
            sizes="(min-width: 1024px) 40vw, 90vw"
            className="object-cover"
            priority
          />
        </Reveal>

        <Reveal delay={120} className="flex flex-col justify-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-accent-bright">
            New Album — {r.year}
          </p>
          <h2 className="mt-3 font-display text-4xl font-semibold leading-[0.95] tracking-tight sm:text-5xl">
            {r.title}
          </h2>
          <p className="mt-5 max-w-[56ch] text-[15px] leading-relaxed text-paper-dim">
            {r.description}
          </p>

          <div className="mt-7 grid grid-cols-2 gap-x-6 gap-y-1 font-mono text-sm text-paper-dim sm:max-w-md">
            {r.tracks.slice(0, 6).map((t, i) => (
              <p key={t}>
                {String(i + 1).padStart(2, "0")}. {t}
              </p>
            ))}
          </div>
          <p className="mt-1 font-mono text-xs text-paper-faint">
            + {r.tracks.length - 6} more
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-6">
            <Link
              href={`/releases/${r.slug}`}
              className="focus-ring border border-paper px-5 py-3 font-mono text-xs uppercase tracking-wide transition-colors hover:bg-paper hover:text-ink"
            >
              Listen to the Album
            </Link>
            <ArrowLink href={`/releases/${r.slug}`} className="text-paper-dim">
              View Release
            </ArrowLink>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
