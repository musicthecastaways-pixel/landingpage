import { Show } from "@/content/types";
import { getShowsByYear } from "@/lib/shows";
import ShowItem from "@/components/ShowItem";
import Reveal from "@/components/Reveal";

export default function ShowTimeline({ shows }: { shows: Show[] }) {
  const byYear = getShowsByYear(shows);

  return (
    <div className="relative">
      {/* center axis — desktop only */}
      <div className="pointer-events-none absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-line lg:block" />
      {/* left axis — mobile/tablet */}
      <div className="pointer-events-none absolute left-3 top-0 h-full w-px bg-line lg:hidden" />

      <div className="flex flex-col gap-16">
        {byYear.map(([year, yearShows]) => (
          <div key={year}>
            <Reveal>
              <div className="relative mb-10 flex justify-center lg:mb-14">
                <span className="relative z-10 bg-ink px-5 font-display text-3xl font-semibold text-paper sm:text-4xl">
                  {year}
                </span>
              </div>
            </Reveal>

            <div className="flex flex-col gap-12">
              {yearShows.map((show, i) => {
                const isRight = i % 2 === 1;
                return (
                  <Reveal key={`${show.date}-${show.venue}`} delay={i * 60}>
                    <div className="relative grid gap-3 pl-10 lg:grid-cols-2 lg:gap-0 lg:pl-0">
                      <span className="absolute left-[9px] top-1.5 h-2.5 w-2.5 -translate-x-1/2 rounded-full bg-accent lg:left-1/2" />
                      {isRight ? (
                        <>
                          <div className="hidden lg:block" />
                          <div className="lg:pl-14">
                            <ShowItem show={show} />
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="lg:pr-14 lg:text-right">
                            <ShowItem show={show} align="right" />
                          </div>
                          <div className="hidden lg:block" />
                        </>
                      )}
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
