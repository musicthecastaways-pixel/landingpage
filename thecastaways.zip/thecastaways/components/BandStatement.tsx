import { band } from "@/content/band";
import Reveal from "@/components/Reveal";

export default function BandStatement() {
  return (
    <section className="px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-[1400px]">
        <Reveal>
          <p className="font-display text-2xl font-medium leading-snug tracking-tight sm:text-4xl sm:max-w-[22ch]">
            {band.statement}
          </p>
        </Reveal>
        <Reveal delay={100}>
          <p className="mt-6 max-w-[62ch] text-[15px] leading-relaxed text-paper-dim sm:text-base">
            {band.bio}
          </p>
        </Reveal>
      </div>
    </section>
  );
}
