import { socials } from "@/content/socials";
import Reveal from "@/components/Reveal";

const gridTiles = [1, 2, 3, 4, 5, 6];

export default function InstagramSection() {
  return (
    <section className="border-t border-line px-5 py-20 sm:px-8 sm:py-24">
      <div className="mx-auto max-w-[1400px]">
        <Reveal className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="mb-2 font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
              Follow
            </p>
            <h2 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
              @thecastawaysmusic
            </h2>
          </div>
          <a
            href={socials.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="underline-hover focus-ring font-mono text-xs uppercase tracking-wide text-paper-dim"
          >
            Open Instagram
          </a>
        </Reveal>

        <a
          href={socials.instagram}
          target="_blank"
          rel="noopener noreferrer"
          className="focus-ring grid grid-cols-3 gap-2 sm:gap-3"
          aria-label="View The Castaways on Instagram"
        >
          {gridTiles.map((n) => (
            <div
              key={n}
              className="group relative aspect-square overflow-hidden bg-ink-raised"
            >
              <div className="absolute inset-0 flex items-center justify-center font-mono text-[11px] uppercase tracking-wide text-paper-faint transition-colors group-hover:text-paper-dim">
                Instagram
              </div>
            </div>
          ))}
        </a>
      </div>
    </section>
  );
}
