import Image from "next/image";
import { Merchandise } from "@/content/types";
import Reveal from "@/components/Reveal";

export default function MerchGrid({ items }: { items: Merchandise[] }) {
  return (
    <div className="grid grid-cols-2 gap-6 sm:gap-8 lg:grid-cols-4">
      {items.map((item, i) => (
        <Reveal key={item.name} delay={i * 70}>
          <div className="relative aspect-[4/5] w-full overflow-hidden bg-ink-raised">
            <Image
              src={item.image}
              alt={item.name}
              fill
              sizes="(min-width: 1024px) 23vw, 45vw"
              className="object-cover"
            />
            {!item.available && (
              <span className="absolute left-3 top-3 bg-ink/80 px-2 py-1 font-mono text-[10px] uppercase tracking-wide text-paper-dim">
                Coming Soon
              </span>
            )}
          </div>
          <div className="mt-3">
            <p className="font-display text-base font-medium leading-tight">
              {item.name}
            </p>
            <p className="mt-1 text-sm text-paper-dim">{item.description}</p>
            <div className="mt-2 flex items-center justify-between">
              <p className="font-mono text-xs uppercase tracking-wide text-paper-faint">
                {item.price}
              </p>
              {item.sizes && (
                <p className="font-mono text-xs uppercase tracking-wide text-paper-faint">
                  {item.sizes.join(" / ")}
                </p>
              )}
            </div>
          </div>
        </Reveal>
      ))}
    </div>
  );
}
