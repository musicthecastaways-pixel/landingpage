import { Show } from "@/content/types";
import { formatShowDate } from "@/lib/shows";

export default function ShowItem({
  show,
  align = "left",
}: {
  show: Show;
  align?: "left" | "right";
}) {
  const { day, month } = formatShowDate(show.date);
  const content = (
    <div
      className={`flex flex-col gap-1 ${
        align === "right" ? "lg:items-end lg:text-right" : ""
      }`}
    >
      <p className="font-display text-2xl font-semibold leading-none">
        {day} <span className="text-accent-bright">{month}</span>
      </p>
      <p className="mt-1 text-[15px] font-medium">
        {show.city}
        {show.country && show.country !== "Brazil" ? `, ${show.country}` : ""}
      </p>
      <p
        className={`font-mono text-sm uppercase tracking-wide ${
          show.placeholder ? "text-paper-faint" : "text-paper-dim"
        }`}
      >
        {show.venue}
      </p>
      {show.bands && show.bands.length > 0 && (
        <p className="font-mono text-xs uppercase tracking-wide text-paper-faint">
          with {show.bands.join(", ")}
        </p>
      )}
      {show.link && (
        <a
          href={show.link}
          target="_blank"
          rel="noopener noreferrer"
          className="underline-hover focus-ring mt-1 w-fit font-mono text-xs uppercase tracking-wide text-accent-bright"
        >
          Event details
        </a>
      )}
    </div>
  );
  return content;
}
