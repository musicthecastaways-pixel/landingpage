"use client";

import Image from "next/image";
import { useState } from "react";
import { Photo } from "@/content/types";
import Reveal from "@/components/Reveal";
import Lightbox from "@/components/Lightbox";

const sizeSpan: Record<NonNullable<Photo["size"]>, string> = {
  lg: "sm:col-span-7 sm:row-span-2",
  md: "sm:col-span-5",
  sm: "sm:col-span-4",
};

export default function PhotoGrid({ photos }: { photos: Photo[] }) {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  return (
    <>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-12 sm:gap-6">
        {photos.map((photo, i) => (
          <Reveal
            key={photo.src}
            delay={(i % 4) * 60}
            className={`group relative ${sizeSpan[photo.size ?? "md"]} ${
              i % 3 === 1 ? "sm:mt-10" : ""
            }`}
          >
            <button
              type="button"
              onClick={() => setActiveIndex(i)}
              className="focus-ring relative block aspect-[4/5] w-full overflow-hidden bg-ink-raised"
              aria-label={`Open photo: ${photo.event}${photo.city ? ", " + photo.city : ""}`}
            >
              <Image
                src={photo.src}
                alt={photo.alt}
                fill
                sizes="(min-width: 640px) 40vw, 92vw"
                loading="lazy"
                className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
              />
              <div className="absolute inset-0 flex items-end bg-gradient-to-t from-ink/80 via-transparent to-transparent p-4 opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-focus-visible:opacity-100">
                <div className="text-left">
                  <p className="font-mono text-xs uppercase tracking-wide text-paper">
                    {photo.event}
                    {photo.city ? ` — ${photo.city}` : ""}
                  </p>
                  {photo.photographer && (
                    <p className="mt-0.5 font-mono text-[11px] uppercase tracking-wide text-paper-faint">
                      Photo by {photo.photographer}
                    </p>
                  )}
                </div>
              </div>
              {/* Mobile-visible metadata (no hover available) */}
              <div className="absolute inset-x-0 bottom-0 bg-ink/70 p-3 sm:hidden">
                <p className="font-mono text-[11px] uppercase tracking-wide text-paper">
                  {photo.event}
                  {photo.city ? ` — ${photo.city}` : ""}
                </p>
              </div>
            </button>
          </Reveal>
        ))}
      </div>

      <Lightbox
        photos={photos}
        activeIndex={activeIndex}
        onClose={() => setActiveIndex(null)}
        onNavigate={setActiveIndex}
      />
    </>
  );
}
