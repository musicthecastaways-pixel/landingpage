import Link from "next/link";
import { band } from "@/content/band";
import SectionHeading from "@/components/ui/SectionHeading";
import Reveal from "@/components/Reveal";

export default function BandHistory() {
  return (
    <section className="border-t border-line px-5 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-[1400px]">
        <SectionHeading
          eyebrow="Since 2021"
          title="History"
          action={
            <Link
              href="/about"
              className="underline-hover focus-ring font-mono text-xs uppercase tracking-wide text-paper-dim"
            >
              Read the Full Story
            </Link>
          }
        />

        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-5">
          {band.history.map((h, i) => (
            <Reveal
              key={`${h.year}-${h.title}`}
              delay={i * 70}
              className="border-t border-line pt-4"
            >
              <p className="font-mono text-sm text-accent-bright">{h.year}</p>
              <p className="mt-2 font-display text-lg font-medium leading-tight">
                {h.title}
              </p>
              <p className="mt-2 text-sm leading-relaxed text-paper-dim">
                {h.text}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
