import Image from "next/image";
import Link from "next/link";
import { Release } from "@/content/types";

export default function ReleaseCard({ release }: { release: Release }) {
  return (
    <Link
      href={`/releases/${release.slug}`}
      className="focus-ring group block"
    >
      <div className="relative aspect-square w-full overflow-hidden bg-ink-raised">
        <Image
          src={release.cover}
          alt={`${release.title} cover art`}
          fill
          sizes="(min-width: 1024px) 23vw, (min-width: 640px) 45vw, 90vw"
          className="object-cover transition-transform duration-500 ease-out group-hover:scale-[1.04]"
        />
      </div>
      <div className="mt-3 flex items-start justify-between gap-3">
        <div>
          <p className="font-display text-lg font-medium leading-tight">
            {release.title}
          </p>
          <p className="mt-1 font-mono text-xs uppercase tracking-wide text-paper-faint">
            {release.year} — {release.type}
          </p>
        </div>
      </div>
    </Link>
  );
}
