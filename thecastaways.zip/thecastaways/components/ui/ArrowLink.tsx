import Link from "next/link";

export default function ArrowLink({
  href,
  children,
  className = "",
}: {
  href: string;
  children: React.ReactNode;
  className?: string;
}) {
  const external = href.startsWith("http") || href.startsWith("mailto:");
  return (
    <Link
      href={href}
      target={external ? "_blank" : undefined}
      rel={external ? "noopener noreferrer" : undefined}
      className={`underline-hover focus-ring inline-block w-fit font-mono text-sm uppercase tracking-wide ${className}`}
    >
      {children}
    </Link>
  );
}
