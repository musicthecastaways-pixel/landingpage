export const socials = {
  instagram: "https://instagram.com/thecastawaysmusic",
  spotify: "",
  youtube: "",
  tiktok: "",
  bandcamp: "",
  facebook: "",
} as const;

export const socialLabels: { key: keyof typeof socials; label: string }[] = [
  { key: "instagram", label: "Instagram" },
  { key: "spotify", label: "Spotify" },
  { key: "youtube", label: "YouTube" },
  { key: "tiktok", label: "TikTok" },
  { key: "bandcamp", label: "Bandcamp" },
  { key: "facebook", label: "Facebook" },
];
