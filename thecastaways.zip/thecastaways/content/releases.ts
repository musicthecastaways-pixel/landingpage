import { Release } from "./types";

export const releases: Release[] = [
  {
    slug: "same-old-things-but-new",
    title: "Same Old Things (But New!)",
    year: 2026,
    type: "Album",
    cover: "/images/releases/same-old-things.jpg",
    current: true,
    description:
      "Thirteen tracks written and produced independently over more than a year, released July 10, 2026 — five years to the day after the band's formation. Lucas Alves mixed and mastered most of the record. \u201cTime Heals\u201d was mixed and mastered by Júnior Vieira at Estúdio Quarto Laranja / Clube do Autoral. \u201cSave Me\u201d features Rafael Christ of Dive Bar; \u201cCheap Thrill\u201d features saxophone by Octávio Furtado.",
    tracks: [
      "As Good As Dead",
      "White Wine",
      "Fading Out",
      "Annie",
      "Time Heals",
      "Save Me",
      "Cheap Thrill",
      "Never Let Go",
      "With You",
      "You Don't Know Me",
      "Break Me Down",
      "Expensive Thrill",
      "Rise",
    ],
    credits: [
      "Independently produced",
      "Mixed and mastered by Lucas Alves, except \u201cTime Heals\u201d",
      "\u201cTime Heals\u201d mixed and mastered by Júnior Vieira, Estúdio Quarto Laranja / Clube do Autoral",
      "\u201cSave Me\u201d features Rafael Christ (Dive Bar)",
      "\u201cCheap Thrill\u201d features saxophone by Octávio Furtado",
    ],
    links: {
      spotify: "",
      appleMusic: "",
      youtube: "",
      bandcamp: "",
    },
  },
  {
    slug: "art-lives-on",
    title: "Art Lives On",
    year: 2023,
    type: "Album",
    cover: "/images/releases/art-lives-on.jpg",
    description:
      "The Castaways' second full-length, and the record that carried the band beyond Pelotas — it has since passed 20,000 plays.",
    tracks: ["TRACKLIST TO BE ADDED"],
    links: {},
  },
  {
    slug: "minuit",
    title: "Minuit",
    year: 2022,
    type: "Acoustic EP",
    cover: "/images/releases/minuit.jpg",
    description:
      "A short acoustic EP, recorded as a quieter counterpart to the band's live shows.",
    tracks: ["TRACKLIST TO BE ADDED"],
    links: {},
  },
  {
    slug: "bleeding-out",
    title: "Bleeding Out",
    year: 2021,
    type: "EP",
    cover: "/images/releases/bleeding-out.jpg",
    description: "The Castaways' first release, built around two tracks.",
    tracks: ["Dark Days", "Red Light"],
    links: {},
  },
];

export const currentRelease = releases.find((r) => r.current)!;
