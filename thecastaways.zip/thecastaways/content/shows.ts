import { Show } from "./types";

// Add new shows anywhere in this list — upcoming/past status and sort
// order are derived automatically from `date` in lib/shows.ts.
// Entries marked `placeholder: true` are demo data standing in for
// real historical shows that haven't been documented yet.
export const shows: Show[] = [
  {
    date: "2026-07-25",
    city: "Pelotas",
    country: "Brazil",
    venue: "Buteco do Franconi",
    bands: ["Upper Vision"],
  },
  {
    date: "2026-08-01",
    city: "Santa Maria",
    country: "Brazil",
    venue: "Gárgula",
    bands: ["Dive Bar"],
  },
  {
    date: "2024-06-14",
    city: "Pelotas",
    country: "Brazil",
    venue: "Bar Opinião",
  },
  {
    date: "2025-03-08",
    city: "Pelotas",
    country: "Brazil",
    venue: "SHOW DATA TO BE ADDED",
    placeholder: true,
  },
  {
    date: "2025-05-17",
    city: "Rio Grande",
    country: "Brazil",
    venue: "SHOW DATA TO BE ADDED",
    placeholder: true,
  },
  {
    date: "2025-07-19",
    city: "Pelotas",
    country: "Brazil",
    venue: "SHOW DATA TO BE ADDED",
    placeholder: true,
  },
  {
    date: "2025-09-06",
    city: "Porto Alegre",
    country: "Brazil",
    venue: "SHOW DATA TO BE ADDED",
    placeholder: true,
  },
  {
    date: "2025-11-15",
    city: "Santa Maria",
    country: "Brazil",
    venue: "SHOW DATA TO BE ADDED",
    placeholder: true,
  },
  {
    date: "2024-03-02",
    city: "Pelotas",
    country: "Brazil",
    venue: "SHOW DATA TO BE ADDED",
    placeholder: true,
  },
  {
    date: "2024-09-21",
    city: "Rio Grande",
    country: "Brazil",
    venue: "SHOW DATA TO BE ADDED",
    placeholder: true,
  },
  {
    date: "2023-11-04",
    city: "Pelotas",
    country: "Brazil",
    venue: "SHOW DATA TO BE ADDED",
    placeholder: true,
  },
  {
    date: "2023-06-17",
    city: "Pelotas",
    country: "Brazil",
    venue: "SHOW DATA TO BE ADDED",
    placeholder: true,
  },
];
