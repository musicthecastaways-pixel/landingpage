export const band = {
  name: "The Castaways",
  origin: "Pelotas, Rio Grande do Sul, Brazil",
  city: "Pelotas",
  country: "Brazil",
  formed: "2021-07-10",
  formedYear: 2021,
  genre: "Alternative rock / grunge",
  statement:
    "Alternative rock from Pelotas, Brazil.",
  bio: "The Castaways write distorted, melodic guitar music built from a Nineties alternative rock lineage — closer to a band that should have existed then and is happening now than to a revival act. Formed in Pelotas in 2021, the group has released four records independently, developed a steady live presence across Rio Grande do Sul, and produced 2026's Same Old Things (But New!) largely on its own terms.",
  email: "music.thecastaways@gmail.com",
  members: [
    { name: "Lucas Alves", role: "Vocals / Guitar" },
    { name: "Everton Cunha", role: "Guitar" },
    { name: "Andrei Lerm", role: "Drums" },
  ],
  formerMembers: [
    {
      name: "Rodrigo Manaã",
      role: "Drums",
      note: "Founding drummer. Later joined Astronautas Marcianos.",
      years: "2021–2022",
    },
    {
      name: "Ricardo \u201cBastião\u201d",
      role: "Bass",
      note: "Bassist during the band's early live years.",
      years: "2022–2024",
    },
  ],
  history: [
    {
      year: "2021",
      title: "Formation",
      text: "The Castaways form in Pelotas with Lucas Alves, Everton Cunha and drummer Rodrigo Manaã. First recordings begin the same year.",
    },
    {
      year: "2021",
      title: "Bleeding Out",
      text: "The band's first release, built around Dark Days and Red Light.",
    },
    {
      year: "2022",
      title: "Andrei joins",
      text: "Rodrigo Manaã leaves to join Astronautas Marcianos; Andrei Lerm takes over on drums. Ricardo \u201cBastião\u201d joins on bass.",
    },
    {
      year: "2022",
      title: "Minuit",
      text: "An acoustic EP, recorded as a quieter counterpoint to the band's live sound.",
    },
    {
      year: "2023",
      title: "Art Lives On",
      text: "A full album that becomes the band's first record to find an audience beyond Pelotas, passing 20,000 plays.",
    },
    {
      year: "2024",
      title: "Live expansion",
      text: "The band plays more regularly around Rio Grande do Sul, including a show at Bar Opinião in Pelotas.",
    },
    {
      year: "2026",
      title: "Same Old Things (But New!)",
      text: "Released July 10 — five years to the day after the band's formation — as a trio of Lucas, Everton and Andrei, following a production process that ran over a year.",
    },
  ],
  epk: {
    label: "Download EPK",
    href: "/epk/the-castaways-epk.pdf",
    available: false,
  },
} as const;
