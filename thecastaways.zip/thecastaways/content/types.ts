export type Show = {
  date: string; // ISO date, e.g. "2026-07-25"
  city: string;
  country: string;
  venue: string;
  bands?: string[];
  link?: string;
  image?: string;
  placeholder?: boolean;
};

export type ReleaseLinks = {
  spotify?: string;
  appleMusic?: string;
  youtube?: string;
  bandcamp?: string;
};

export type Release = {
  slug: string;
  title: string;
  year: number;
  type: "EP" | "Album" | "Acoustic EP";
  cover: string;
  description: string;
  tracks: string[];
  credits?: string[];
  links?: ReleaseLinks;
  current?: boolean;
};

export type Photo = {
  src: string;
  alt: string;
  event: string;
  city?: string;
  date?: string;
  photographer?: string;
  size?: "sm" | "md" | "lg";
};

export type Merchandise = {
  name: string;
  description: string;
  image: string;
  price?: string;
  sizes?: string[];
  available: boolean;
  link?: string;
};
