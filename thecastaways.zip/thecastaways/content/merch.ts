import { Merchandise } from "./types";

export const merch: Merchandise[] = [
  {
    name: "Castaways Tee",
    description: "Black / White",
    image: "/images/merch/tee.jpg",
    price: "PRICE TO BE ADDED",
    sizes: ["S", "M", "L", "XL"],
    available: false,
  },
  {
    name: "Same Old Things Hoodie",
    description: "Heavyweight hoodie, back print",
    image: "/images/merch/hoodie.jpg",
    price: "PRICE TO BE ADDED",
    sizes: ["S", "M", "L", "XL"],
    available: false,
  },
  {
    name: "Castaways Beanie",
    description: "Embroidered logo",
    image: "/images/merch/beanie.jpg",
    price: "PRICE TO BE ADDED",
    available: false,
  },
  {
    name: "Sticker Pack",
    description: "Set of five",
    image: "/images/merch/stickers.jpg",
    price: "PRICE TO BE ADDED",
    available: false,
  },
];
