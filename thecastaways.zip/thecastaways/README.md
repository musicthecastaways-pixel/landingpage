# The Castaways — Official Website

Next.js (App Router) + TypeScript + Tailwind CSS v4 site for The Castaways,
an independent alternative rock band from Pelotas, Rio Grande do Sul, Brazil.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Build & deploy

```bash
npm run build
npm run start   # production server, or deploy the repo directly to Vercel
```

The project is a standard Next.js app and deploys to Vercel with no extra
configuration — import the repo at vercel.com/new.

## Where to edit content

Everything content-related lives in `/content` as typed data — no need to
touch components to update text, shows, releases, photos or merch:

| File | Controls |
|---|---|
| `content/band.ts` | Name, bio, lineup, former members, history timeline, EPK link |
| `content/shows.ts` | Every show. Add an entry anywhere in the array — `lib/shows.ts` automatically sorts it into "Upcoming" or the historical timeline based on `date`. Entries with `placeholder: true` are demo data; replace `venue: "SHOW DATA TO BE ADDED"` with the real show and remove the flag |
| `content/releases.ts` | Discography — one object per release/EP, with tracklist, credits and streaming links |
| `content/photos.ts` | Photo archive — each entry needs `event`, optional `city`/`date`/`photographer`, and a `size` (`sm`/`md`/`lg`) to control its footprint in the grid |
| `content/merch.ts` | Merch catalog items |
| `content/socials.ts` | Central social URLs — swap in the real Spotify/YouTube/TikTok/Bandcamp/Facebook links as they're set up |

## Where to place real assets

- **Hero video**: add the file at `public/videos/hero.mp4` and set it as a
  `<source>` inside `components/Hero.tsx` (currently shows a poster only,
  since no reel was supplied).
- **Photos**: replace files in `public/images/photos/` (same filenames, or
  update `content/photos.ts` to point at new ones).
- **Album covers**: `public/images/releases/`.
- **Band portrait**: `public/images/band/portrait.svg` → swap for a real
  photo (any format works, just update the extension in `app/about/page.tsx`).
- **Logo**: currently a text wordmark in `SiteHeader.tsx`. Drop an SVG at
  `public/images/band/logo.svg` and swap it in when ready.

All placeholder images are generated SVGs so the site never breaks waiting
on real photography — swap files in place, no code changes required.

## EPK

`band.epk.href` in `content/band.ts` points at `/epk/the-castaways-epk.pdf`.
Drop the real PDF at `public/epk/the-castaways-epk.pdf` once it exists (and
set `band.epk.available` to `true` if you want to gate the button on it).

## Social URLs

Only Instagram (`@thecastawaysmusic`) was confirmed — everything else in
`content/socials.ts` is an empty string and renders as "Coming Soon" until
filled in.

## Fonts

Space Grotesk, Work Sans and Space Mono are self-hosted in `public/fonts/`
and loaded via `next/font/local` in `app/layout.tsx`, so the build never
depends on reaching Google Fonts at build time.

## SEO

Metadata, Open Graph tags, canonical URLs, `robots.txt` and `sitemap.xml`
are already wired up (`app/layout.tsx`, `app/robots.ts`, `app/sitemap.ts`).
Update `siteUrl` in `app/layout.tsx` and `base` in `app/sitemap.ts` once the
real domain is live.
