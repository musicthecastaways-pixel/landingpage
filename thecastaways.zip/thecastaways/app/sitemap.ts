import { MetadataRoute } from "next";
import { releases } from "@/content/releases";

const base = "https://thecastawaysmusic.com";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = [
    "",
    "/shows",
    "/photos",
    "/releases",
    "/about",
    "/merch",
    "/contact",
  ].map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date(),
  }));

  const releaseRoutes = releases.map((r) => ({
    url: `${base}/releases/${r.slug}`,
    lastModified: new Date(),
  }));

  return [...staticRoutes, ...releaseRoutes];
}
