import type { Metadata } from "next";
import { releases } from "@/content/releases";
import ReleaseGrid from "@/components/ReleaseGrid";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = {
  title: "Releases",
  description:
    "The Castaways' full discography — Bleeding Out, Minuit, Art Lives On and Same Old Things (But New!).",
  alternates: { canonical: "/releases" },
};

export default function ReleasesPage() {
  const sorted = [...releases].sort((a, b) => b.year - a.year);

  return (
    <div className="px-5 pb-28 pt-16 sm:px-8 sm:pt-24">
      <div className="mx-auto max-w-[1400px]">
        <Reveal>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
            Discography
          </p>
          <h1 className="mt-2 font-display text-5xl font-semibold tracking-tight sm:text-6xl">
            Releases
          </h1>
        </Reveal>

        <div className="mt-16">
          <ReleaseGrid releases={sorted} />
        </div>
      </div>
    </div>
  );
}
