import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { releases } from "@/content/releases";
import Reveal from "@/components/Reveal";

export function generateStaticParams() {
  return releases.map((r) => ({ slug: r.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const release = releases.find((r) => r.slug === slug);
  if (!release) return {};
  return {
    title: release.title,
    description: release.description,
    alternates: { canonical: `/releases/${release.slug}` },
    openGraph: {
      title: `${release.title} — The Castaways`,
      description: release.description,
      images: [release.cover],
    },
  };
}

const linkLabels: Record<string, string> = {
  spotify: "Spotify",
  appleMusic: "Apple Music",
  youtube: "YouTube",
  bandcamp: "Bandcamp",
};

export default async function ReleaseDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const release = releases.find((r) => r.slug === slug);
  if (!release) notFound();

  const links = release.links
    ? Object.entries(release.links).filter(([, v]) => v)
    : [];

  return (
    <div className="px-5 pb-28 pt-16 sm:px-8 sm:pt-24">
      <div className="mx-auto max-w-[1400px]">
        <Link
          href="/releases"
          className="underline-hover focus-ring font-mono text-xs uppercase tracking-wide text-paper-dim"
        >
          ← All Releases
        </Link>

        <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,520px)_1fr] lg:gap-20">
          <Reveal className="relative aspect-square w-full max-w-[520px] overflow-hidden bg-ink-raised">
            <Image
              src={release.cover}
              alt={`${release.title} cover art`}
              fill
              sizes="(min-width: 1024px) 40vw, 90vw"
              className="object-cover"
              priority
            />
          </Reveal>

          <Reveal delay={100}>
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-accent-bright">
              {release.year} — {release.type}
            </p>
            <h1 className="mt-3 font-display text-4xl font-semibold leading-[0.95] tracking-tight sm:text-5xl">
              {release.title}
            </h1>
            <p className="mt-6 max-w-[58ch] text-[15px] leading-relaxed text-paper-dim">
              {release.description}
            </p>

            {links.length > 0 && (
              <div className="mt-8 flex flex-wrap gap-4">
                {links.map(([key, url]) => (
                  <a
                    key={key}
                    href={url as string}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="focus-ring border border-paper px-5 py-3 font-mono text-xs uppercase tracking-wide transition-colors hover:bg-paper hover:text-ink"
                  >
                    {linkLabels[key] ?? key}
                  </a>
                ))}
              </div>
            )}

            <div className="mt-14">
              <h2 className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
                Tracklist
              </h2>
              <ol className="flex flex-col gap-1.5 border-t border-line pt-4">
                {release.tracks.map((track, i) => (
                  <li
                    key={track}
                    className="flex gap-4 font-display text-base sm:text-lg"
                  >
                    <span className="font-mono text-sm text-paper-faint">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    {track}
                  </li>
                ))}
              </ol>
            </div>

            {release.credits && release.credits.length > 0 && (
              <div className="mt-14">
                <h2 className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
                  Credits
                </h2>
                <ul className="flex flex-col gap-2 border-t border-line pt-4">
                  {release.credits.map((c) => (
                    <li
                      key={c}
                      className="text-sm leading-relaxed text-paper-dim"
                    >
                      {c}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </Reveal>
        </div>
      </div>
    </div>
  );
}
