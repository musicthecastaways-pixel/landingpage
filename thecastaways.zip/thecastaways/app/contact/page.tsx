import type { Metadata } from "next";
import { band } from "@/content/band";
import { socials, socialLabels } from "@/content/socials";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Booking and press contact for The Castaways — an independent alternative rock band from Pelotas, Brazil.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <div className="px-5 pb-28 pt-16 sm:px-8 sm:pt-24">
      <div className="mx-auto max-w-[1400px]">
        <Reveal>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
            Booking &amp; Press
          </p>
          <h1 className="mt-2 font-display text-5xl font-semibold tracking-tight sm:text-6xl">
            Contact
          </h1>
        </Reveal>

        <div className="mt-16 grid gap-16 lg:grid-cols-[minmax(0,560px)_1fr]">
          <Reveal delay={80}>
            <p className="max-w-[52ch] text-[15px] leading-relaxed text-paper-dim">
              For shows, festivals, press or general inquiries, reach out
              directly — The Castaways handle booking themselves.
            </p>

            <a
              href={`mailto:${band.email}`}
              className="focus-ring mt-8 block w-fit font-display text-2xl font-medium underline-hover sm:text-3xl"
            >
              {band.email}
            </a>

            <div className="mt-10 flex flex-wrap gap-4">
              <a
                href={`mailto:${band.email}?subject=Booking Inquiry`}
                className="focus-ring border border-paper px-6 py-3.5 font-mono text-sm uppercase tracking-wide transition-colors hover:bg-paper hover:text-ink"
              >
                Book The Castaways
              </a>
              <a
                href={band.epk.href}
                className="focus-ring border border-accent px-6 py-3.5 font-mono text-sm uppercase tracking-wide text-accent-bright transition-colors hover:bg-accent hover:text-paper"
              >
                Download EPK
              </a>
            </div>
          </Reveal>

          <Reveal delay={160}>
            <h2 className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
              Social
            </h2>
            <ul className="flex flex-col gap-1 border-t border-line pt-4">
              {socialLabels.map(({ key, label }) => {
                const url = socials[key];
                return (
                  <li
                    key={key}
                    className="flex items-center justify-between border-b border-line py-3"
                  >
                    <span className="font-display text-lg">{label}</span>
                    {url ? (
                      <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="underline-hover focus-ring font-mono text-xs uppercase tracking-wide text-paper-dim"
                      >
                        Open
                      </a>
                    ) : (
                      <span className="font-mono text-xs uppercase tracking-wide text-paper-faint">
                        Coming Soon
                      </span>
                    )}
                  </li>
                );
              })}
            </ul>

            <p className="mt-8 font-mono text-xs uppercase tracking-wide text-paper-faint">
              {band.origin}
            </p>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
