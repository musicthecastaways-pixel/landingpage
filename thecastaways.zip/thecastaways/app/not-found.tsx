import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center px-5 text-center">
      <p className="font-display text-[28vw] font-semibold leading-none tracking-tight sm:text-[16rem]">
        404
      </p>
      <p className="mt-4 font-mono text-sm uppercase tracking-wide text-paper-dim">
        This page is as good as dead.
      </p>
      <Link
        href="/"
        className="focus-ring mt-10 border border-paper px-6 py-3.5 font-mono text-sm uppercase tracking-wide transition-colors hover:bg-paper hover:text-ink"
      >
        Go Back
      </Link>
    </div>
  );
}
