import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import { band } from "@/content/band";

// Self-hosted (no runtime call to Google Fonts): swap for the same
// families via next/font/google if you'd rather let Next.js manage them.
const spaceGrotesk = localFont({
  src: "../public/fonts/SpaceGrotesk[wght].ttf",
  variable: "--font-space-grotesk",
  weight: "500 700",
  display: "swap",
});

const workSans = localFont({
  src: "../public/fonts/WorkSans[wght].ttf",
  variable: "--font-work-sans",
  weight: "400 600",
  display: "swap",
});

const spaceMono = localFont({
  src: [
    { path: "../public/fonts/SpaceMono-Regular.ttf", weight: "400", style: "normal" },
    { path: "../public/fonts/SpaceMono-Bold.ttf", weight: "700", style: "normal" },
  ],
  variable: "--font-space-mono",
  display: "swap",
});

const siteUrl = "https://thecastawaysmusic.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "The Castaways — Alternative Rock from Pelotas, Brazil",
    template: "%s — The Castaways",
  },
  description:
    "The Castaways are an independent alternative rock / grunge band from Pelotas, Rio Grande do Sul, Brazil, active since 2021. Booking, releases, shows and photos.",
  keywords: [
    "The Castaways",
    "The Castaways Pelotas",
    "The Castaways band",
    "Brazilian grunge band",
    "Brazilian alternative rock",
    "alternative rock Pelotas",
    "Pelotas rock band",
  ],
  openGraph: {
    title: "The Castaways — Alternative Rock from Pelotas, Brazil",
    description:
      "Independent alternative rock / grunge band from Pelotas, Brazil. Booking, releases, shows and photos.",
    url: siteUrl,
    siteName: "The Castaways",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "The Castaways",
    description: "Alternative rock from Pelotas, Brazil.",
  },
  alternates: {
    canonical: "/",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${spaceGrotesk.variable} ${workSans.variable} ${spaceMono.variable}`}
    >
      <body className="min-h-screen bg-ink text-paper flex flex-col">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[100] focus:bg-accent focus:text-paper focus:px-4 focus:py-2 focus:text-sm"
        >
          Skip to content
        </a>
        <SiteHeader />
        <main id="main" className="flex-1">
          {children}
        </main>
        <SiteFooter />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "MusicGroup",
              name: band.name,
              genre: "Alternative Rock",
              foundingDate: band.formed,
              foundingLocation: band.origin,
              email: band.email,
              url: siteUrl,
            }),
          }}
        />
      </body>
    </html>
  );
}
