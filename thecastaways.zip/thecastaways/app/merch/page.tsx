import type { Metadata } from "next";
import { merch } from "@/content/merch";
import MerchGrid from "@/components/MerchGrid";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = {
  title: "Merch",
  description: "The Castaways merchandise — tees, hoodies and more.",
  alternates: { canonical: "/merch" },
};

export default function MerchPage() {
  return (
    <div className="px-5 pb-28 pt-16 sm:px-8 sm:pt-24">
      <div className="mx-auto max-w-[1400px]">
        <Reveal>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
            Store
          </p>
          <h1 className="mt-2 font-display text-5xl font-semibold tracking-tight sm:text-6xl">
            Merch
          </h1>
          <p className="mt-4 max-w-[54ch] text-[15px] leading-relaxed text-paper-dim">
            The store isn&apos;t connected yet — here&apos;s what&apos;s
            coming. Check back soon or follow @thecastawaysmusic for
            restocks.
          </p>
        </Reveal>

        <div className="mt-16">
          <MerchGrid items={merch} />
        </div>
      </div>
    </div>
  );
}
