import Hero from "@/components/Hero";
import BandStatement from "@/components/BandStatement";
import LatestRelease from "@/components/LatestRelease";
import UpcomingShows from "@/components/UpcomingShows";
import SelectedPhotos from "@/components/SelectedPhotos";
import BandHistory from "@/components/BandHistory";
import ReleaseGrid from "@/components/ReleaseGrid";
import InstagramSection from "@/components/InstagramSection";
import BookingCTA from "@/components/BookingCTA";
import SectionHeading from "@/components/ui/SectionHeading";
import { releases } from "@/content/releases";
import Link from "next/link";

export default function Home() {
  return (
    <>
      <Hero />
      <BandStatement />
      <LatestRelease />
      <UpcomingShows />
      <SelectedPhotos />
      <BandHistory />

      <section className="border-t border-line px-5 py-20 sm:px-8 sm:py-28">
        <div className="mx-auto max-w-[1400px]">
          <SectionHeading
            eyebrow="Discography"
            title="Releases"
            action={
              <Link
                href="/releases"
                className="underline-hover focus-ring font-mono text-xs uppercase tracking-wide text-paper-dim"
              >
                All Releases
              </Link>
            }
          />
          <ReleaseGrid releases={releases} />
        </div>
      </section>

      <InstagramSection />
      <BookingCTA />
    </>
  );
}
