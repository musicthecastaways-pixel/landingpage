import type { Metadata } from "next";
import Image from "next/image";
import { band } from "@/content/band";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = {
  title: "About",
  description:
    "The story of The Castaways — an independent alternative rock band from Pelotas, Brazil, active since 2021.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <div className="px-5 pb-28 pt-16 sm:px-8 sm:pt-24">
      <div className="mx-auto max-w-[1400px]">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,440px)_1fr] lg:gap-20">
          <Reveal>
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
              Since {band.formedYear}
            </p>
            <h1 className="mt-2 font-display text-5xl font-semibold leading-[0.95] tracking-tight sm:text-6xl">
              About
            </h1>
            <p className="mt-6 max-w-[46ch] text-[15px] leading-relaxed text-paper-dim">
              {band.bio}
            </p>

            <div className="relative mt-10 aspect-[4/5] w-full max-w-sm overflow-hidden bg-ink-raised">
              <Image
                src="/images/band/portrait.jpg"
                alt="The Castaways band portrait"
                fill
                sizes="(min-width: 1024px) 30vw, 90vw"
                className="object-cover"
              />
            </div>

            <div className="mt-10">
              <h2 className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
                Lineup
              </h2>
              <ul className="flex flex-col gap-3 border-t border-line pt-4">
                {band.members.map((m) => (
                  <li key={m.name} className="flex justify-between gap-4">
                    <span className="font-display text-lg font-medium">
                      {m.name}
                    </span>
                    <span className="font-mono text-sm text-paper-dim">
                      {m.role}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          <div>
            <h2 className="mb-10 font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
              History
            </h2>
            <div className="relative border-l border-line pl-8">
              {band.history.map((h, i) => (
                <Reveal
                  key={`${h.year}-${h.title}`}
                  delay={i * 60}
                  className="relative pb-12 last:pb-0"
                >
                  <span className="absolute -left-[calc(2rem+3px)] top-1.5 h-2.5 w-2.5 rounded-full bg-accent" />
                  <p className="font-mono text-sm text-accent-bright">
                    {h.year}
                  </p>
                  <h3 className="mt-1 font-display text-2xl font-semibold">
                    {h.title}
                  </h3>
                  <p className="mt-2 max-w-[56ch] text-[15px] leading-relaxed text-paper-dim">
                    {h.text}
                  </p>
                </Reveal>
              ))}
            </div>

            {band.formerMembers.length > 0 && (
              <Reveal delay={200} className="mt-4">
                <h2 className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
                  Former Members
                </h2>
                <ul className="flex flex-col gap-4 border-t border-line pt-4">
                  {band.formerMembers.map((m) => (
                    <li key={m.name}>
                      <p className="font-display text-lg font-medium">
                        {m.name}{" "}
                        <span className="font-mono text-sm font-normal text-paper-faint">
                          {m.years}
                        </span>
                      </p>
                      <p className="text-sm text-paper-dim">{m.note}</p>
                    </li>
                  ))}
                </ul>
              </Reveal>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
