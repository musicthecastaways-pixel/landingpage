import type { Metadata } from "next";
import { photos } from "@/content/photos";
import PhotoGrid from "@/components/PhotoGrid";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = {
  title: "Photos",
  description:
    "Live and studio photography from The Castaways — an editorial archive of the band on and off stage.",
  alternates: { canonical: "/photos" },
};

export default function PhotosPage() {
  return (
    <div className="px-5 pb-28 pt-16 sm:px-8 sm:pt-24">
      <div className="mx-auto max-w-[1400px]">
        <Reveal>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
            Archive
          </p>
          <h1 className="mt-2 font-display text-5xl font-semibold tracking-tight sm:text-6xl">
            Photos
          </h1>
        </Reveal>

        <div className="mt-16">
          <PhotoGrid photos={photos} />
        </div>
      </div>
    </div>
  );
}
