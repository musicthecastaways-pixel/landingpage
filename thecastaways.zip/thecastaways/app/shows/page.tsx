import type { Metadata } from "next";
import { getUpcomingShows, getPastShows } from "@/lib/shows";
import ShowItem from "@/components/ShowItem";
import ShowTimeline from "@/components/ShowTimeline";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = {
  title: "Shows",
  description:
    "Upcoming Castaways shows and a full chronological archive of past performances in Rio Grande do Sul, Brazil.",
  alternates: { canonical: "/shows" },
};

export default function ShowsPage() {
  const upcoming = getUpcomingShows();
  const past = getPastShows();

  return (
    <div className="px-5 pb-28 pt-16 sm:px-8 sm:pt-24">
      <div className="mx-auto max-w-[1400px]">
        <Reveal>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
            Live
          </p>
          <h1 className="mt-2 font-display text-5xl font-semibold tracking-tight sm:text-6xl">
            Shows
          </h1>
        </Reveal>

        {upcoming.length > 0 && (
          <section className="mt-16">
            <h2 className="mb-8 font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
              Upcoming Shows
            </h2>
            <div className="grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
              {upcoming.map((show, i) => (
                <Reveal key={`${show.date}-${show.venue}`} delay={i * 70}>
                  <ShowItem show={show} />
                </Reveal>
              ))}
            </div>
          </section>
        )}

        <section className="mt-24">
          <h2 className="mb-14 font-mono text-xs uppercase tracking-[0.2em] text-paper-faint">
            All Shows
          </h2>
          <ShowTimeline shows={past} />
        </section>
      </div>
    </div>
  );
}
