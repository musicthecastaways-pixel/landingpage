import { shows } from "@/content/shows";
import { Show } from "@/content/types";

function toDate(show: Show) {
  return new Date(`${show.date}T00:00:00`);
}

export function getUpcomingShows(referenceDate: Date = new Date()): Show[] {
  return shows
    .filter((s) => toDate(s).getTime() >= startOfDay(referenceDate).getTime())
    .sort((a, b) => toDate(a).getTime() - toDate(b).getTime());
}

export function getPastShows(referenceDate: Date = new Date()): Show[] {
  return shows
    .filter((s) => toDate(s).getTime() < startOfDay(referenceDate).getTime())
    .sort((a, b) => toDate(b).getTime() - toDate(a).getTime());
}

export function getShowsByYear(showList: Show[]): [string, Show[]][] {
  const map = new Map<string, Show[]>();
  for (const show of showList) {
    const year = show.date.slice(0, 4);
    if (!map.has(year)) map.set(year, []);
    map.get(year)!.push(show);
  }
  return Array.from(map.entries()).sort((a, b) => Number(b[0]) - Number(a[0]));
}

function startOfDay(date: Date) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}

export function formatShowDate(iso: string) {
  const d = new Date(`${iso}T00:00:00`);
  return {
    day: d.toLocaleDateString("en-US", { day: "2-digit" }),
    month: d.toLocaleDateString("en-US", { month: "short" }).toUpperCase(),
  };
}
